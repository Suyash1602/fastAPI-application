FastAPI application
